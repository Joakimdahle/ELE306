﻿static void oppgave1a()
{
    int a = 1000;
    double b = -33.33;
    string c = "programmering og mikrokontrollere";
    bool d = false;
    string[] e = { "en", "to","tre","fire","fem" };
    char f = 'a';
}
static void oppgave1b()
{
    int A = Convert.ToInt32(Console.ReadLine());
    int B = Convert.ToInt32(Console.ReadLine());
    if (A == B)
    {
        Console.WriteLine("tallene er like store!");
    }
    else if (A<B)
    {
        Console.WriteLine("Tall B er størst");
    }
    else
    {
        Console.WriteLine("Tall A er størst");
    }
}
static void oppgave1c()
{
    string tekst = "Hold deg hjemme, vask hendene!!";
    for (int i = 0; i < 50; i++)
    {
        Console.WriteLine(tekst);
    }
}
static void oppgave1d()
{
    for (int i = 500;i <= 1000;i++)
    {
        if (i%2==0)
        {
            Console.WriteLine(i);
        }
    }
}
static void oppgave1e()
{
    for (int i = 1000; i >= 500; i--)
    {
        if (i % 2 == 0)
        {
            Console.WriteLine(i);
        }
    }
}
static void oppgave1f()
{
    try
    {
        Console.Write("Skriv inn ett heltall mellom 1 og 5: ");
        int tall = Convert.ToInt32(Console.ReadLine());
        string[] tallstring = { "en", "to", "tre", "fire", "fem" };
        Console.WriteLine(tallstring[tall - 1]);
    }
    catch (Exception ex)
    {
        Console.WriteLine("tallet var utenfor området!");
    }
}
static void oppgave1g()
{
    int [] elementer = new int[100];
    Random random = new Random();
    for (int i = 0; i < elementer.Length; i++)
    {
        elementer[i] = random.Next(10,99);
        Console.WriteLine(elementer[i]);
    }
}
static void oppgave1h()
{
    Console.Write("skriv inn antall tall du ønsker: ");
    int L = Convert.ToInt32(Console.ReadLine());  
    int[] tabell = new int[L];
    Random random = new Random();
    for (int i = 0;i < tabell.Length;i++) //legger litt ekstra på oppgaven sånn at jeg kan sjekke att programmet mitt virker uavhengig  av start verdier
    {
        tabell[i] = random.Next(1,100);
        Console.Write(tabell[i]+" ");
    }
    Console.WriteLine();
    Array.Sort(tabell);
    for (int i = 0; i<tabell.Length; i++)
    {
        Console.Write(tabell[i]+" ");
    }
    Console.WriteLine();
}
static void oppgave1j()
{
    Console.Write("skriv inn dimensjon: ");
    int dimensjon = Convert.ToInt32(Console.ReadLine());
    int teller = dimensjon;
    for (int j = 0; j < dimensjon; j++)
    {
        for (int i = 0; i < teller; i++)
        {
            Console.Write('#');
        }
        teller--;
        Console.WriteLine();
    }

}
static void oppgave1k()
{
    bool loop = true;
    while (loop)
    try
    {
        Console.Write("Skriv inn ett heltall mellom 1 og 100: ");
        int tall = Convert.ToInt32(Console.ReadLine());
        if ((tall<1)||(tall>100))
            {
                Console.WriteLine("taller var ikke innenfor rekkeviddet 1 til 100");
            }
        else
            {
                Console.WriteLine(tall);
                loop = false;
            }
    }
    catch (Exception ex)
    {
            Console.WriteLine("taller var ikke innenfor rekkeviddet 1 til 100");
        }
}
static void oppgave2()
{
    Console.Write("Skriv inn ett tall: ");
    int antall = Convert.ToInt32(Console.ReadLine());
    string [] ord = new string [antall];
    for (int i = 0;i < antall;i++)
    {
        Console.Write ("Skriv inn ord {0}: ",i+1);
        ord [i] = Console.ReadLine();
    }
    Console.Write("Ord med fire eller flere bokstaver: ");
    for (int i = 0; i<antall; i++)
    {
        if (ord[i].Length > 4)
        {
            Console.Write(ord[i]+"  ");
        }
    }

}
